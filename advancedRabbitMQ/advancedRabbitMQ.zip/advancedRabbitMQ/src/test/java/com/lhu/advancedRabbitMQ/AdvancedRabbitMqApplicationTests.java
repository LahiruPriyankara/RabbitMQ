package com.lhu.advancedRabbitMQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedRabbitMqApplicationTests {

	@Test
	void contextLoads() {
	}

}
