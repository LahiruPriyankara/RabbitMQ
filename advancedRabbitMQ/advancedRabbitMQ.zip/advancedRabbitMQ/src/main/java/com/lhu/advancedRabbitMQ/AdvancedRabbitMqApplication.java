package com.lhu.advancedRabbitMQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedRabbitMqApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvancedRabbitMqApplication.class, args);
	}

}
